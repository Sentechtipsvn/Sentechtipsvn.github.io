# ShareWifi 0.1.0 beta 1 — Kiểm chứng

## Đã hoàn thành

- Build app UIKit và controller Mach-O arm64, bật `-Wall -Wextra -Werror`.
- Deployment target 15.0, package/runtime gate chỉ nhắm iPhone 7 Plus / iOS 15.8.8.
- Đóng gói rootless; kiểm tra payload, filter chỉ SpringBoard, ID app và 4 menu nhấn giữ.
- Pseudo-sign ad-hoc bằng ldid; xác minh hash trang mã của cả binary app và controller.
- Bộ kiểm tra đọc Mach-O xác nhận đúng loại executable/dylib và thư viện liên kết rootless.
- Test parser ARP với ASan/UBSan: khung đúng, padding 4 byte cho tên interface, nhiều bản ghi, dữ liệu cắt cụt, MAC multicast/không hợp lệ, sockaddr hỏng và version không hỗ trợ.
- LeakSanitizer bị host ptrace chặn; chạy lại với `detect_leaks=0`. Không có cấp phát heap trong parser.
- Kiểm tra nguồn: bật và tắt theo thứ tự, khóa lệnh khi đang chạy, readback từng bước, timeout dừng, hoàn tác, refresh tách khỏi file điều khiển.

## Chưa kiểm chứng trên iPhone thật

- Khả dụng/quyền thực tế của C API CoreTelephony, BluetoothManager và hotspot controller trên 15.8.8.
- Giá trị getter so với giao diện Cài đặt khi hotspot dùng Wi-Fi ở chế độ AP.
- Menu nhấn giữ, hook chạm biểu tượng, kéo sắp xếp và khả năng hiển thị toast.
- Bộ đếm tethering native, quyền đọc DHCP và framing ARP thực tế trên máy Sếp.
- Kết nối Internet từ iPhone 11, ngủ/khóa màn hình, carrier/VPN hoặc xung đột tweak khác.
- Mọi khẳng định về tốc độ thực tế, độ mượt, độ hao pin và tỷ lệ thành công.

Không có dữ liệu thiết bị, packet capture hay tài khoản Apple được dùng trong quá trình build. Báo cáo `packages/Verification.json` chỉ chứng minh kiểm tra tĩnh/host nêu trên, không chứng minh tính năng đã chạy trên iOS.

## Công cụ

- SDK: iPhoneOS15.6 từ theos/sdks.
- Compiler: Clang 11.1.0, L1ghtmann/llvm-project release test-210562a.
- Theos headers/libs rootless; không đóng gói SDK/toolchain vào ZIP.
- `dpkg-deb --root-owner-group -Zxz -z9`.

Mã nguồn và biểu tượng gốc nằm trong ZIP kèm theo để bảo trì.
