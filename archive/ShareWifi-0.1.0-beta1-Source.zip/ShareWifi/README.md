# ShareWifi · 0.1.0 beta 1

Biểu tượng bật/tắt nhanh bộ chia sẻ mạng trên **iPhone 7 Plus, iOS 15.8.8, Dopamine rootless**.

**Chưa thử trên thiết bị thật.** Đã biên dịch app và controller, kiểm tra gói/chữ ký và thử bộ phân tích ARP trên máy build. Các API riêng, thao tác biểu tượng, công tắc radio/hotspot và giao diện cần được kiểm chứng trên iPhone của Sếp.

## Cài đặt

1. Lưu `ShareWifi-0.1.0-beta1-iphoneos-arm64.deb` vào Tệp.
2. Mở bằng Sileo để cài. Nếu menu Chia sẻ không có Sileo, mở gói trong Filza và chọn Install; giải quyết phụ thuộc qua Sileo nếu được yêu cầu.
3. Respring một lần để nạp controller vào SpringBoard. Không cần sửa MobileGestalt, không cần mua chứng chỉ hoặc ký qua AltStore.
4. Tìm **ShareWifi** ngoài màn hình chính. Nếu chưa thấy biểu tượng, kiểm tra cài thành công trong Sileo và làm mới icon cache bằng công cụ có sẵn trên máy; gói có chạy `uicache` nhưng không tự khởi động lại SpringBoard.

Gói dành cho iPhone9,2 / iPhone9,4, iOS 15.8.8. Không dành cho iPhone 11 chưa jailbreak.

## Sử dụng

- **Chạm biểu tượng:** nếu hook biểu tượng khớp, bật/tắt cả bộ ngay tại Home và hiện thông báo kết quả. Khi iOS đang cho sửa vị trí biểu tượng, không chiếm thao tác. Nếu hook không khớp, ứng dụng mở bảng điều khiển để dùng nút lớn.
- **Nhấn giữ → Bảng điều khiển:** mở giao diện mà không tự bật/tắt kết nối.
- **Nhấn giữ → Thiết bị kết nối:** mở danh sách máy vừa thấy.
- **Nhấn giữ → Bật chia sẻ mạng / Tắt cả bộ kết nối:** yêu cầu trạng thái cụ thể.
- Trong bảng điều khiển có nút **Hoàn tác lần thay đổi gần nhất**, **Kiểm tra Internet**, **Tùy chỉnh** và **Chẩn đoán**.
- **Tùy chỉnh → Luôn mở bảng điều khiển** nếu Sếp muốn chạm biểu tượng chỉ mở giao diện; thay đổi này không cần respring.

Rời giao diện, mở app khác hoặc khóa màn hình không gửi lệnh tắt. Hotspot vẫn do iOS quản lý; bản này không chống cơ chế tự ngắt hotspot khi không có máy dùng, không phát dữ liệu giả để giữ mạng.

## Bật và tắt những gì?

| Bật | Tắt |
| --- | --- |
| Dữ liệu di động → Wi-Fi → Bluetooth → Điểm truy cập cá nhân | Điểm truy cập cá nhân → dữ liệu di động → Wi-Fi → Bluetooth |

Đợi từng công tắc phản ánh trạng thái mong muốn trước khi đi bước tiếp. Nếu hết thời gian chờ, dừng và báo có thể đã thay đổi một phần. Không báo thành công chỉ vì đã gửi lệnh.

Nếu hotspot đang tắt nhưng một số radio đang bật, thao tác biểu tượng chọn bật chia sẻ. Muốn tắt cả bốn ngay trong trạng thái này, dùng **Tắt cả bộ kết nối** trong menu nhấn giữ hoặc bảng điều khiển.

Tắt dữ liệu di động không bật chế độ máy bay. ShareWifi không tắt sóng nghe gọi/SMS và không sửa APN, carrier, VPN, firewall, NAT, tên hoặc mật khẩu hotspot. Tắt Wi-Fi/Bluetooth có thể ngắt tai nghe và các phụ kiện đang dùng — đây là hành vi của nút Tắt cả bộ theo yêu cầu.

**Hoàn tác** khôi phục bốn trạng thái trước lần thay đổi gần nhất trong phiên SpringBoard hiện tại. Respring/khởi động lại làm mất bản ghi hoàn tác. Nếu API bị hệ thống từ chối thì hoàn tác cũng có thể không thực hiện đủ; luôn đọc trạng thái từng dòng.

## Thiết bị kết nối: hiểu đúng dữ liệu

- **Kết nối hệ thống:** đọc bộ đếm tethering của SpringBoard khi ivar tồn tại và kiểu/kích thước hợp lệ. Không đọc được thì ghi rõ chưa xác định, không thay bằng số 0.
- **Danh sách thiết bị:** đọc ARP, chỉ giữ những mục thuộc giao diện/subnet hotspot hiện tại và đối chiếu tên trong DHCP khi đọc được file hệ thống.
- ARP có thể còn máy đã rời đi. Mỗi dòng được ghi **Vừa thấy trong ARP · chưa xác nhận còn kết nối**. Đây không phải danh sách association Wi-Fi trực tiếp.
- Không bảo đảm có tên/model cho mọi máy. Chạm một dòng để đặt tên riêng, ví dụ “iPhone 11 của Sếp”. Tên gắn với MAC hiện tại; MAC riêng tư đổi thì cần gán lại.
- Chưa thống kê dung lượng, chặn máy, ngắt riêng từng máy hoặc giới hạn dữ liệu trong bản này.

Danh sách cập nhật khi mở bảng điều khiển. Không quét toàn bộ mạng, không đọc nội dung gói tin. Không tự cho các máy khác là khách hotspot chỉ vì thấy chúng trên Wi-Fi nhà.

## Internet

Sau khi bật thành công, ShareWifi thử tải trang kiểm tra kết nối HTTPS của Apple một lần. Nút **Kiểm tra Internet** thực hiện cùng phép thử theo yêu cầu. Không gửi danh sách thiết bị, mật khẩu hoặc MAC tới Apple.

Kết quả chỉ cho biết **iPhone 7 Plus** truy cập được trang kiểm tra. Không chứng minh iPhone 11 đang nhận được Internet và không khẳng định đường ra là 4G nếu máy có đường mạng khác/VPN. Lỗi kiểm tra không tự tắt hotspot.

## Lần thử đầu trên iPhone

1. Xác nhận hotspot thủ công đang dùng được trong Cài đặt của iOS, SIM/gói cước có dữ liệu.
2. Cài/respring, chờ ít nhất vài giây rồi nhấn giữ ShareWifi → Bảng điều khiển.
3. Kiểm tra cả bốn trạng thái có đọc được không. Nếu có dòng “Chưa đọc được”, chọn **Chẩn đoán → Sao chép** gửi lại thông tin đó; không sửa thêm hệ thống để ép chạy.
4. Thử Bật. Kiểm tra lại trong Cài đặt của iOS, kết nối iPhone 11 và mở một trang web từ iPhone 11.
5. Thử Tắt cả bộ. Xác nhận hotspot dừng, dữ liệu di động/Wi-Fi/Bluetooth tắt, còn nghe gọi/SMS.
6. Thử Hoàn tác; thử rời app và khóa màn hình khi đang chia sẻ.
7. Thử chạm biểu tượng, nhấn giữ mở bảng điều khiển và kéo sắp xếp biểu tượng. Nếu thao tác một chạm chưa hoạt động nhưng bảng điều khiển dùng được, báo đúng khác biệt đó.

Các trường hợp bắt buộc thử thêm: tắt/bật liên tục khi đang xử lý; không có sóng/SIM; đang bật chế độ máy bay; có tai nghe Bluetooth; đổi công tắc từ Control Center khi ShareWifi đang chạy; thiết bị khách ngủ hoặc rời hotspot. Bản này chưa xác nhận các tình huống trên.

## Khi có lỗi

- **Chưa nhận trạng thái mới:** kiểm tra controller đã nạp sau respring và đang bật nạp tweak trong Dopamine. Chờ vài giây, bấm làm mới.
- **API chưa khớp:** mở Chẩn đoán và gửi nội dung. Controller sẽ từ chối thao tác nếu chưa đọc được trạng thái hoặc không có hàm điều khiển cần thiết.
- **Chỉ đổi được một phần:** xem bốn dòng trạng thái; chọn Hoàn tác nếu muốn. Có thể điều khiển thủ công trong Cài đặt.
- **Mạng bật nhưng chưa có Internet:** kiểm tra gói cước, sóng và VPN; việc bật công tắc không bảo đảm nhà mạng cấp mạng.
- **SpringBoard crash hoặc không vào Home:** tắt nạp tweak khi jailbreak lại bằng Dopamine, gỡ ShareWifi bằng Sileo/Filza rồi bật lại nạp tweak. Không cần sửa SenSwipe.

Gỡ ShareWifi không cố thay đổi radio đang dùng, không tự sửa mạng hay xóa cấu hình hệ thống. Sau khi gỡ, Sếp điều khiển các công tắc bằng Cài đặt như bình thường. Thư mục dữ liệu riêng có thể còn để giữ tên thiết bị/tùy chọn khi cài lại.

## Cấu trúc / build

- `Sources/Controller.m`: controller nạp riêng vào SpringBoard, điều phối bất đồng bộ, kiểm tra chữ ký phương thức, chờ phản hồi và hoàn tác.
- `Sources/SWClients.m`: bộ đọc interface, DHCP và ARP chỉ đọc.
- `Sources/SWArp.c`: parser framing XNU, kiểm tra độ dài trước mỗi lần đọc.
- `App/main.m`: UIKit app và menu nhấn giữ; không tự tắt mạng khi giao diện đóng.
- `Sources/SWCommon.h`: file IPC atomic, thư mục 0700, file 0600. Refresh có notification riêng để không ghi đè lệnh bật/tắt đang chờ.
- Không có daemon root, không mở cổng mạng điều khiển, không chạy shell từ dữ liệu nhập.

Build cần Theos headers/libs rootless, iPhoneOS15.6 SDK, toolchain iOS arm64 có clang/ldid và dpkg-deb:

```sh
THEOS=/path/to/theos SDK_PATH=/path/to/iPhoneOS15.6.sdk \
IOS_TOOLCHAIN_BIN=/path/to/ios-toolchain/bin bash scripts/build.sh
python3 scripts/verify_package.py packages/ShareWifi-0.1.0-beta1-iphoneos-arm64.deb
```

Test parser dùng GCC trên Linux:

```sh
mkdir -p build/tests
gcc -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer \
  -I Sources tests/arp_test.c Sources/SWArp.c -o build/tests/arp_test
ASAN_OPTIONS=detect_leaks=0 build/tests/arp_test
```

ASan/UBSan được bật; riêng LeakSanitizer tắt do host chạy dưới ptrace. Bộ parser không cấp phát heap. Các test trên không thay thế kiểm thử iOS thật.

## Tham khảo

- [Flipswitch / Hotspot](https://github.com/a3tweaks/Flipswitch/blob/master/Switches/Hotspot.x): tên API của công tắc hotspot native. ShareWifi không chép hook/triển khai Flipswitch và không đóng gói mã GPL của dự án này.
- [WiCellSwitcher](https://github.com/BrunoNFL/WiCellSwitcher): tham khảo tên C API dữ liệu di động.
- [HotspotPro](https://github.com/dangkhoa116/hotspotpro): đối chiếu ABI routing XNU và giới hạn của ARP/DHCP. Parser và UI ShareWifi được viết riêng; không đóng gói code hoặc binary HotspotPro.

Những nguồn trên không xác nhận ShareWifi tương thích iOS 15.8.8. Bản này cần kiểm chứng trên thiết bị thật.

© Sentechtipsvn · MIT License
