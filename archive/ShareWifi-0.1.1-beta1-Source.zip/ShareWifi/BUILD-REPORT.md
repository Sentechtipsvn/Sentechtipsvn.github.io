# ShareWifi 0.1.1 beta 1 — Báo cáo sửa lỗi

## Dữ liệu từ thiết bị Sếp

Ảnh chẩn đoán 0.1.0 beta 1: hotspot unknown; data 0; bluetooth 0; wifi 1; phase error; iconTapHook true; systemCount 0; apiError rỗng. Đây là kiểm chứng khả năng cài/nạp và đọc ba radio của bản cũ, không phải kiểm chứng bản sửa.

## Nguyên nhân mã nguồn và thay đổi

- Tên property discoverable bị dùng làm selector. Khai báo tham khảo chỉ rõ getter isDiscoverable.
- Kiểu trả về của _toggleState bị giới hạn là void, trong khi khai báo tham khảo trả về BOOL.
- Sửa resolver getter, dùng chung kiểm tra ABI của getter/action; chỉ nhận action không đối số trả về void hoặc BOOL hợp lệ.
- Dùng NSInvocation và đọc lại trạng thái; không diễn giải NO trả về từ toggle là thao tác tắt thất bại.
- Giữ luồng điều phối, preflight, timeout, hoàn tác, ba radio, ARP, biểu tượng và menu nhấn giữ.
- Bổ sung hotspotAPI vào chẩn đoán; giữ ID gói/app để nâng cấp đè và giữ cấu hình.

## Đã kiểm chứng trên máy build

- Cả app và controller biên dịch với -Wall -Wextra -Werror.
- Test hồi quy ABI: getter B/c và action B/c/v được chấp nhận đúng kích thước; từ chối số đối số sai, object-return, NULL và kích thước sai. Chạy AddressSanitizer/UBSan.
- Chạy lại test parser ARP hiện có, qua các trường hợp framing/padding/truncation/malformed/MAC/version.
- LeakSanitizer vẫn tắt do host ptrace; không có test thiết bị hoặc giả lập NSInvocation trong những bài test C.
- Kiểm tra payload rootless, Mach-O arm64, chữ ký code-page, ID, bộ menu, giới hạn firmware. SHA-256 và thư viện liên kết ở packages/Verification.json.

## Chưa kiểm chứng

- Bản sửa 0.1.1 chưa chạy trên iPhone 7 Plus của Sếp.
- Cần xác nhận controller/getter thực tế qua hotspotAPI, khả năng bật/tắt hotspot, kết nối iPhone 11 và hoàn tác.
- Test host không chứng minh quyền API hay Internet trên iOS.

Công cụ build không đổi: iPhoneOS15.6 SDK; Clang 11.1.0 từ L1ghtmann test-210562a; Theos libs rootless; ldid và dpkg-deb.
